package com.cg.ams.daoservices;

import java.util.List;

import com.cg.ams.beans.Student;

public interface AMSDAO {
	 
	Student save(Student student);
	boolean update(Student student);
	Student findOne(int studentID);
	List<Student> findAll();
	//Student [] findAll();
}
