package com.cg.ams.daoservices;

import java.util.ArrayList;
import java.util.List;

import com.cg.ams.beans.Student;
import com.cg.ams.util.AMSUtil;

public class AMSDAOImpl implements  AMSDAO {

	@Override
	public Student save(Student student) {
		student.setStudentID(AMSUtil.getSTUDENT_ID_COUNTER());
		AMSUtil.students.put(student.getStudentID(), student);
		//AttendenceSystemUtil.students[AttendenceSystemUtil.getSTUDENT_INDEX()] = student;
		return  student;
	}

	@Override
	public boolean update(Student student) {
		AMSUtil.students.put(student.getStudentID(), student);
		return true;
	}

	@Override
	public Student findOne(int studentID) {
		return AMSUtil.students.get(studentID);		
		/*for (Student student : AttendenceSystemUtil.students) 
			if (student != null &&  student.getStudentID() == studentID) {
				return student;
			}
		return null;*/
	}

	@Override
	public List<Student> findAll(){
		return new ArrayList<>(AMSUtil.students.values());
	}
	/*public Student[] findAll() {
		// TODO Auto-generated method stub
		return AttendenceSystemUtil.students;
	}*/
}
