package com.cg.ams.services;

import java.util.List;

import com.cg.ams.beans.CourseDetails;
import com.cg.ams.beans.ExamFeeDetails;
import com.cg.ams.beans.LectureDetails;
import com.cg.ams.beans.Student;
import com.cg.ams.daoservices.AMSDAO;
import com.cg.ams.daoservices.AMSDAOImpl;
import com.cg.ams.exception.StudentDetailsNotFoundException;
import com.cg.ams.util.AMSUtil;

public class AMSServicesImpl implements  AMSServices{

	AMSDAO attendenceSystemDAO = new AMSDAOImpl();

	@Override
	public int acceptStudentDetails(String firstName, String lastName, CourseDetails courseDetails,
			LectureDetails lectureDetails, ExamFeeDetails examFeeDetails) {
		Student student = new Student(firstName, lastName, courseDetails, lectureDetails, examFeeDetails);
		student = attendenceSystemDAO.save(student);
		return student.getStudentID();
	}

	@Override
	public int calculatePenalty(int studentID) throws StudentDetailsNotFoundException {
		Student student = new Student(studentID);
		student = this.getStudentDetails(studentID);
		//calculating perctge
		student.getLectureDetails().setAttendencePerctge((student.getLectureDetails().getNoOfLecturesAttented()*100)/student.getLectureDetails().getNoOfLecturesConducted());
		if(student.getLectureDetails().getAttendencePerctge()>=75 && student.getLectureDetails().getAttendencePerctge() <= 100) {
			System.out.println("loop1 : " + student.getLectureDetails().getAttendencePerctge());
			student.getExamFeeDetails().setPenaltyToBePaid(0);
			student.getExamFeeDetails().setTotalExamFeeToBePaid(student.getExamFeeDetails().getExamFeeToBePaid()+student.getExamFeeDetails().getPenaltyToBePaid());
			attendenceSystemDAO.update(student);
			return student.getExamFeeDetails().getTotalExamFeeToBePaid();
		}
		else if (student.getLectureDetails().getAttendencePerctge() < 75 && student.getLectureDetails().getAttendencePerctge() >= 60) {
			System.out.println("loop2 : " + student.getLectureDetails().getAttendencePerctge());
			student.getExamFeeDetails().setPenaltyToBePaid((student.getExamFeeDetails().getExamFeeToBePaid()*10/100));
			student.getExamFeeDetails().setTotalExamFeeToBePaid(student.getExamFeeDetails().getExamFeeToBePaid() + student.getExamFeeDetails().getPenaltyToBePaid());
			attendenceSystemDAO.update(student);
			return student.getExamFeeDetails().getTotalExamFeeToBePaid();
		}
		else if (student.getLectureDetails().getAttendencePerctge() < 60 && student.getLectureDetails().getAttendencePerctge() >= 50) {
			System.out.println("loop3 : " + student.getLectureDetails().getAttendencePerctge());
			student.getExamFeeDetails().setPenaltyToBePaid((student.getExamFeeDetails().getExamFeeToBePaid()*20/100));
			student.getExamFeeDetails().setTotalExamFeeToBePaid(student.getExamFeeDetails().getExamFeeToBePaid() + student.getExamFeeDetails().getPenaltyToBePaid());
			attendenceSystemDAO.update(student);
			return student.getExamFeeDetails().getTotalExamFeeToBePaid();
		}
		else {
			System.out.println("loop4 : " + student.getLectureDetails().getAttendencePerctge());
			student.getExamFeeDetails().setPenaltyToBePaid((student.getExamFeeDetails().getExamFeeToBePaid()*30/100));
			student.getExamFeeDetails().setTotalExamFeeToBePaid(student.getExamFeeDetails().getExamFeeToBePaid() + student.getExamFeeDetails().getPenaltyToBePaid());
			attendenceSystemDAO.update(student);
			return student.getExamFeeDetails().getTotalExamFeeToBePaid();
		}
	}

	@Override
	public Student getStudentDetails(int studentID) throws StudentDetailsNotFoundException {
		Student student=attendenceSystemDAO.findOne(studentID);
		if(student==null)	throw new  StudentDetailsNotFoundException("Student Id is not found"+studentID);
		return student;
	}

	@Override
	public List<Student> getAllStudentDetails(){
		List<Student> listOfStudents = attendenceSystemDAO.findAll();
		return listOfStudents;

	}
	/*public Student [] getAllStudentDetails() {

		//return AttendenceSystemUtil.students;
	}*/
}
