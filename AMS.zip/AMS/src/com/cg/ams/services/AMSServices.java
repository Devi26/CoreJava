package com.cg.ams.services;

import java.util.List;

import com.cg.ams.beans.CourseDetails;
import com.cg.ams.beans.ExamFeeDetails;
import com.cg.ams.beans.LectureDetails;
import com.cg.ams.beans.Student;
import com.cg.ams.exception.StudentDetailsNotFoundException;

public interface AMSServices {

	int acceptStudentDetails(String firstName, String lastName, CourseDetails courseDetails, LectureDetails lectureDetails,
			ExamFeeDetails examFeeDetails);
	Student getStudentDetails(int studentID) throws StudentDetailsNotFoundException;
	List<Student> getAllStudentDetails();
	//Student[] getAllStudentDetails();
	int calculatePenalty(int studentID) throws StudentDetailsNotFoundException;
}
