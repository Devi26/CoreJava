package com.cg.ams.util;

import java.util.HashMap;

import com.cg.ams.beans.Student;

public class AMSUtil {
 
	//private static int STUDENT_ID_COUNTER = 50;
	public static int STUDENT_ID_COUNTER = 50;
	
	//public static Student [] students = new Student[10];
	
	public static HashMap<Integer, Student> students = new HashMap<>();
	
	//private static int STUDENT_INDEX  = 0;
	
	public static int getSTUDENT_ID_COUNTER() {
		return ++STUDENT_ID_COUNTER;
	}
	
	/*public static int getSTUDENT_INDEX() {
		return STUDENT_INDEX ++;
		
	}*/
}
