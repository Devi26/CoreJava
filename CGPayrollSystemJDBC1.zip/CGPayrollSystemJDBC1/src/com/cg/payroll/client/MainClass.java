package com.cg.payroll.client;

import java.io.IOException;
import java.sql.SQLException;
import com.cg.payroll.util.DBUtil;

public class MainClass{
	public static void main(String[] args) {
			DBUtil dbUtil = new DBUtil();
			dbUtil.getDBConnection();
			System.out.println("Connection Open");
	}
} 