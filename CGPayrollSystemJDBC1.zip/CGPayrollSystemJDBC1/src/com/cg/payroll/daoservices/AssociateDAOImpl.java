package com.cg.payroll.daoservices;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import com.cg.payroll.beans.Associate;

public class AssociateDAOImpl implements AssociateDAO {

	@Override
	public Associate save(Associate associate) {
		return null;
	}

	@Override
	public boolean update(Associate associate) {
		return false;
	}

	@Override
	public Associate findOne(int associateId) {
		return null;
	}

	@Override
	public List<Associate> findAll() {
		return null;
	}

	@Override
	public boolean removeAssociate(int associateId) {
		return false;
	}

	
}


