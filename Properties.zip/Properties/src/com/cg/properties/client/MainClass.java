package com.cg.properties.client;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class MainClass {
	
	public static void main(String [] args) {
		
		try {
			Properties projectProperties = new Properties();
			projectProperties.load(new FileInputStream(".\\resources\\project.properties"));
			
			String value1 = projectProperties.getProperty("key1" );
			String value2 = projectProperties.getProperty("key2" );
			String value3 = projectProperties.getProperty("key3" );
			System.out.println("val1 = " + value1 + " " + "val2 = " + value2 + " " + "val3 = " + value3);
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}

}
