package com.cg.bank.test;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.cg.bank.customer.Account;
import com.cg.bank.customer.Customer;
import com.cg.bank.customernotfoundexception.CustomerNotFoundException;
import com.cg.bank.services.BankService;
import com.cg.bank.services.BankServicesImpl;
import com.cg.bank.util.BankUtil;

class BankServiceTest {
	static BankService bankService;
	@Before
	public static void setUpTestEnv() {
		bankService=new BankServicesImpl();
	}
	@Before
	public void setUpData1() {
		Customer customer=new Customer(101,998918921, 3168520, 260196, "Devi", "Ratnala", "dssri.26@gmail.com", "BXGPR5236Q", new Account(5745, 200, "saving"));

		Customer customer2=new Customer(102, 99898647, 3167645, 260197, "Surya", "Ratnala", "deviss@gmail.com", "GFDHGF7H4", new Account(5745, 200, "saving"));
		BankUtil.customers.put(customer.getCustomerID(),customer);
		BankUtil.customers.put(customer2.getCustomerID(),customer);
	}
	@Test
	public void testAcceptCustomerDetailsForValidData() {
		int expectedCustomerID=103;
		int actualCustomerId=bankService.acceptCustomerDetails( 960393, 3168123, 260198, "Surya","Sri", "devi@gmail.com", "GFHDFG676","Bhimavaram","Andhra Pradesh", "India",12345, 
				29000, "saving");
		Assert.assertEquals(expectedCustomerID, actualCustomerId);

	}

	@Test(expected=CustomerNotFoundException.class)
	public void testGetCustomerDataForInvalidAssociateID() throws CustomerNotFoundException {
		bankService.getCustomerDetails(200);
	}

	@After
	public void tearDownTestData() {
		BankUtil.CUSTOMER_ID_COUNTER=100;
		BankUtil.customers.clear();
	}
	@After
	public static void tearDownTestEnv() {
		bankService=null;
	}
}
