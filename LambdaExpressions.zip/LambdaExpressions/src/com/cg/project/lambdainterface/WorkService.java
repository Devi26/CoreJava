package com.cg.project.lambdainterface;

public interface WorkService {
void doSomeWork();

}
