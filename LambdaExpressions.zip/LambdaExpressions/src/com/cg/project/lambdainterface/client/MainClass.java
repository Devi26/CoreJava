package com.cg.project.lambdainterface.client;

import java.security.Provider.Service;

import com.cg.project.lambdainterface.FunctionalInterface1;
import com.cg.project.lambdainterface.FunctionalInterface2;
import com.cg.project.lambdainterface.FunctionalInterface3;
import com.cg.project.lambdainterface.WorkService;

public class MainClass {

	public static void main(String[] args) {
		FunctionalInterface1 ref1 = (firstName, lastName)->System.out.println("Good Morning " + firstName + " " + lastName);
		ref1.greetUser("Devi", "Ratnala");

		FunctionalInterface2 ref2 = (a,b)->a+b;
		System.out.println(ref2.add(10, 20));

		FunctionalInterface3 ref3 = (str1, str2)-> str1.toUpperCase() + " " + str2.toUpperCase();
		System.out.println(ref3.toUpperCase("devi", "ratnala"));

		callForWork(() -> System.out.println("Doing Some Work"));
	}
	public static void callForWork(WorkService WorkService) {
		WorkService.doSomeWork();
	}
}
