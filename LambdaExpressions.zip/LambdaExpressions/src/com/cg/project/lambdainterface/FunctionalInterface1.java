package com.cg.project.lambdainterface;

public interface FunctionalInterface1 {
	public void greetUser(String firstName, String lastName);
}
