package com.cg.project.lambdainterface;

public interface FunctionalInterface3 {
	public String toUpperCase(String str1, String str2);

}
