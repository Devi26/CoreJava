package com.cg.payroll.daoservices;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

//import java.awt.List;

import com.cg.payroll.beans.Associate;

public interface AssociateDAO {

	Associate save(Associate associate);
	boolean update(Associate associate);
	Associate findOne(int associateId);
	//Associate [] findAll();
	List<Associate> findAll();
	//Map<Associate, associate> findAll();
	boolean removeAssociate(int associateId);
}
