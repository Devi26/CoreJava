package com.cg.payroll.daoservices;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import com.cg.payroll.beans.Associate;

public class AssociateDAOImpl implements AssociateDAO {

	@Override
	public Associate save(Associate associate) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean update(Associate associate) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Associate findOne(int associateId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Associate> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean removeAssociate(int associateId) {
		// TODO Auto-generated method stub
		return false;
	}

	
}


