package com.cg.payroll.util;
//code for connection opening in data base
//to create properties file we need to right click on project / source folder / folder name as resources----> next again right click on resources / new / other / extract "general" / file / next / give file name 

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.util.Properties;

public class DBUtil {
	private static Connection con;
	public Connection getDBConnection() throws FileNotFoundException, IOException {
		if(con == null) {
			Properties dbProperties = new Properties();
			dbProperties.load(new FileInputStream(new File(".//resources//payroll.properties")));
			String driver = dbProperties.getProperty("driver");
			String url = dbProperties.getProperty("url");
			String user = dbProperties.getProperty("user");
			String password = dbProperties.getProperty("password");
			}
		return con;		
	}
}
