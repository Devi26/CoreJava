package com.cg.payroll.services;

import java.util.List;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.daoservices.AssociateDAOImpl;
import com.cg.payroll.exception.AssociateDetailsNotFoundException;
import com.cg.payroll.exception.InvalidEmailException;

public class PayrollServicesImpl implements PayrollServices{

	//private AssociateDAO associateDAO = new AssociateDAOImpl();

	private AssociateDAO associateDAO;

	public PayrollServicesImpl() {
		associateDAO = new AssociateDAOImpl();
	}

	public PayrollServicesImpl(AssociateDAO associateDAO) {
		super();
		this.associateDAO = associateDAO;
	}

	@Override
	public int acceptAssociateDetails(int yearlyInvestmentUnder80c, String firstName, String lastName, String department,
			String designation, String pancard, String emailId, int basicSalary, int epf, int companyPf, int accountNumber, String bankName, String ifscCode) throws InvalidEmailException {

		Associate associate = new Associate(yearlyInvestmentUnder80c, firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode));
		associate=associateDAO.save(associate);
		//Testing
		
		if(!associate.getEmailId().contains("@")) throw new InvalidEmailException();
		//if(associate.getFirstName().)
		/*Pattern p = Pattern.compile("\\b[A-Z0-9._%-]+@[A-Z0-9.-]+\\.[A-Z]{2,4}\\b");
		Matcher m = p.matcher("foobar@gmail.com");
		if (!m.find()) throw new  InvalidEmailException();*/
		
		return associate.getAssociateID();
	}

	@Override
	public int calculateNetSalary(int associateID) throws AssociateDetailsNotFoundException {

		Associate associate = new Associate(associateID);
		associate=this.getAssociateDetails(associateID);
		//associateDAO.update(associate);

		associate.getSalary().setHra(associate.getSalary().getBasicSalary() * 40/100);
		associate.getSalary().setConveyanceAllowance(associate.getSalary().getBasicSalary() * 30/100);
		associate.getSalary().setOtherAllowance(associate.getSalary().getBasicSalary() * 20/100);
		associate.getSalary().setPersonalAllowance(associate.getSalary().getBasicSalary() * 20/100);
		associate.getSalary().setMonthlyGrossSalary(associate.getSalary().getHra() + associate.getSalary().getConveyanceAllowance() + associate.getSalary().getOtherAllowance() + associate.getSalary().getPersonalAllowance() + associate.getSalary().getEpf() + associate.getSalary().getCompanyPf());
		associate.getSalary().setAnnualGrossSalary(associate.getSalary().getMonthlyGrossSalary() * 12);

		if (associate.getSalary().getAnnualGrossSalary() <= 25000) {
			associate.getSalary().setYearlyTax(0);
			associate.getSalary().setNetSalary(associate.getSalary().getMonthlyGrossSalary() - associate.getSalary().getCompanyPf() - associate.getSalary().getEpf() - associate.getSalary().getMonthlyTax());
			associateDAO.update(associate);
			return associate.getSalary().getNetSalary();
		} 
		else if (associate.getSalary().getAnnualGrossSalary() > 250000 && associate.getSalary().getAnnualGrossSalary() <= 500000 ) {
			associate.getSalary().setYearlyTax(associate.getSalary().getAnnualGrossSalary() - associate.getSalary().getCompanyPf() * 12 - associate.getSalary().getEpf() * 12 - associate.getYearlyInvestmentUnder80c());
			associate.getSalary().setYearlyTax(associate.getSalary().getYearlyTax() * 10/100);
			associate.getSalary().setMonthlyTax(associate.getSalary().getYearlyTax() / 12);
			associate.getSalary().setNetSalary(associate.getSalary().getMonthlyGrossSalary() - associate.getSalary().getCompanyPf() - associate.getSalary().getEpf() - associate.getSalary().getMonthlyTax());
			associateDAO.update(associate);
			return associate.getSalary().getNetSalary();
		} 
		if (associate.getSalary().getAnnualGrossSalary() > 500000 && associate.getSalary().getAnnualGrossSalary() <= 1000000 ) {
			associate.getSalary().setYearlyTax(associate.getSalary().getAnnualGrossSalary() - associate.getSalary().getCompanyPf() * 12 - associate.getSalary().getEpf() * 12 );
			associate.getSalary().setYearlyTax(associate.getSalary().getYearlyTax() * 20/100);
			associate.getSalary().setMonthlyTax(associate.getSalary().getYearlyTax() / 12);
			associate.getSalary().setNetSalary(associate.getSalary().getMonthlyGrossSalary() - associate.getSalary().getCompanyPf() - associate.getSalary().getEpf() - associate.getSalary().getMonthlyTax());
			associateDAO.update(associate);
			return associate.getSalary().getNetSalary();	
		} 
		else {
			associate.getSalary().setYearlyTax(associate.getSalary().getAnnualGrossSalary() - associate.getSalary().getCompanyPf() * 12 - associate.getSalary().getEpf() * 12 );
			associate.getSalary().setYearlyTax(associate.getSalary().getYearlyTax() * 30/100);
			associate.getSalary().setMonthlyTax(associate.getSalary().getYearlyTax() / 12);
			associate.getSalary().setNetSalary(associate.getSalary().getMonthlyGrossSalary() - associate.getSalary().getCompanyPf() - associate.getSalary().getEpf() - associate.getSalary().getMonthlyTax());
			associateDAO.update(associate);
			return associate.getSalary().getNetSalary();
		}
		/*	int hra, conveyanceAllowance, otherAllowance, personalAllowance, monthlyGrossSalary, annualGrossSalary, netSalary, basicSalary;
		int monthlyTax, yearlyTax;

		hra = associate.getSalary().getBasicSalary() * 40/100;
		conveyanceAllowance = associate.getSalary().getBasicSalary() * 30/100;
		otherAllowance = associate.getSalary().getBasicSalary() * 20/100;
		personalAllowance = associate.getSalary().getBasicSalary() * 20/100;

		monthlyGrossSalary =  hra + conveyanceAllowance + personalAllowance + otherAllowance + associate.getSalary().getCompanyPf() + associate.getSalary().getEpf();

		annualGrossSalary = monthlyGrossSalary * 12;

		if(annualGrossSalary <=250000) {
			netSalary = monthlyGrossSalary - associate.getSalary().getEpf() - associate.getSalary().getCompanyPf() ;
			System.out.println("Net Salary = " + netSalary);
			return netSalary;
		}
		else {
			if (annualGrossSalary > 250000   annualGrossSalary <= 500000) {

				yearlyTax = annualGrossSalary - associate.getSalary().getCompanyPf() * 12 - associate.getSalary().getEpf() * 12 - associate.getYearlyInvestmentUnder80c();
				yearlyTax = yearlyTax * 10/100;
				monthlyTax = yearlyTax / 12;
				netSalary = monthlyGrossSalary - associate.getSalary().getCompanyPf() - associate.getSalary().getEpf() - monthlyTax;
			}
			else if (annualGrossSalary > 500000 && annualGrossSalary <= 1000000) {
				yearlyTax = annualGrossSalary - associate.getSalary().getCompanyPf() * 12 - associate.getSalary().getEpf() * 12 ;
				yearlyTax = yearlyTax * 20/100;
				monthlyTax = yearlyTax / 12;
				netSalary = monthlyGrossSalary - associate.getSalary().getCompanyPf() - associate.getSalary().getEpf() - monthlyTax;
				System.out.println("Net Salary = " + netSalary);
				return netSalary;
			}
			else {
				yearlyTax = annualGrossSalary - associate.getSalary().getCompanyPf() * 12 - associate.getSalary().getEpf() * 12;
				yearlyTax = yearlyTax * 30/100;
				monthlyTax = yearlyTax / 12;
				netSalary = monthlyGrossSalary - associate.getSalary().getCompanyPf() - associate.getSalary().getEpf() - monthlyTax;
				System.out.println("Net Salary = " + netSalary);
				return netSalary;
			}
		}*/
		//return (int)netSalary;
	}

	@Override
	public Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFoundException {
		Associate associate = associateDAO.findOne(associateId);
		if(associate == null) throw new AssociateDetailsNotFoundException("Associate Details Not Found " + associateId);
		return associate;
	}

	@Override
	public List<Associate> getallAssociateDetails() {

		//List<Associate> listOfAssociates = associateDAO.findAll();
		return associateDAO.findAll();
		//public Associate[] getallAssociateDetails() {
		//return null;

		//return PayrollUtil.associates;                                                                             
	}
	
}
