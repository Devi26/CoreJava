package com.cg.project.beans;

public class ElectricalBEGraduateStudent extends Student {

	private String stBranch;
	private int noOfSems; 
	String gradeOfLabExams = "A+"; 
	String totalGrade = " ";
	
	public void calStudentMarks(){
		
		int [] marksOfSems  = {90,91,85,98,89,81,80,90};
		int totalMarks = 0;
		for (int marks : marksOfSems) {
			totalMarks = totalMarks + marks;
		}
		
		int percentage = (totalMarks/marksOfSems.length) * 100;

		System.out.println(" Total Marks of a Graduate Student : " +totalMarks);	
		System.out.println(" Percentage of a Graduate Student : " +percentage);	

		
		if (percentage>=90)
			totalGrade = "A+";
		if (percentage>=75&&percentage<=60)
			totalGrade = "A";
		if (percentage>=59&&percentage<=50)
			totalGrade = "B";
		if (percentage>=49&&percentage<=35)
			totalGrade = "C";
		if (percentage<=34)
			totalGrade = "FAIL";
		System.out.println("Grade of ElectricalBEGraduateStudent : " +  totalGrade);
		
	}
	
	public ElectricalBEGraduateStudent() {}

	public ElectricalBEGraduateStudent(int stRegNO, int stAge, String stFirstName, String stLastName, String stPlace) {
		super(stRegNO, stAge, stFirstName, stLastName, stPlace);
		// TODO Auto-generated constructor stub
	}

	public ElectricalBEGraduateStudent(String stBranch, int noOfSems, String gradeOfLabExams, String totalGrade) {
		super();
		this.stBranch = stBranch;
		this.noOfSems = noOfSems;
		this.gradeOfLabExams = gradeOfLabExams;
		this.totalGrade = totalGrade;
	}

	public String getStBranch() {
		return stBranch;
	}

	public void setStBranch(String stBranch) {
		this.stBranch = stBranch;
	}

	public int getNoOfSems() {
		return noOfSems;
	}

	public void setNoOfSems(int noOfSems) {
		this.noOfSems = noOfSems;
	}

	public String getGradeOfLabExams() {
		return gradeOfLabExams;
	}

	public void setGradeOfLabExams(String gradeOfLabExams) {
		this.gradeOfLabExams = gradeOfLabExams;
	}

	public String getTotalGrade() {
		return totalGrade;
	}

	public void setTotalGrade(String totalGrade) {
		this.totalGrade = totalGrade;
	}
	
	
	
	
	
}
