package com.cg.project.beans;

public class GraduateStudent extends Student {
	
	private String degree;
	
	public void calStudentMarks(){
		
		int [] marks = {99,98,97,96,95,94};
		int totalMarks = 0;
				for (int num : marks) {
				totalMarks = totalMarks + num;
				}
		int percentage = (totalMarks/marks.length) * 100;	
		System.out.println(" Total Marks of a Graduate Student : " +totalMarks);	
		System.out.println(" Percentage of a Graduate Student : " +percentage);	
	}
	public GraduateStudent() {}
	
	public GraduateStudent(int stRegNO, int stAge, String stFirstName, String stLastName, String stPlace, String degree) {
		super(stRegNO, stAge, stFirstName, stLastName, stPlace);
	}
	
	
	public GraduateStudent(String degree) {
		super();
		this.degree = degree;
	}
	public String getDegree() {
		return degree;
	}
	public void setDegree(String degree) {
		this.degree = degree;
	}
	@Override
	public String toString() {
		return super.toString() + "degree=" + degree + ", getDegree()=" + getDegree() + ", getStRegNO()=" + getStRegNO()
				+ ", getStAge()=" + getStAge() + ", getStFirstName()=" + getStFirstName() + ", getStLastName()="
				+ getStLastName() + ", getStPlace()=" + getStPlace() + ", getClass()=" + getClass() + ", hashCode()="
				+ hashCode() + ", toString()=" + super.toString() ;
	}
	
	
	
}
