package com.cg.project.beans;

public class BEGraduateStudent extends Student {

	private String stUniName;
	public void calStudentMarks(){

		int [] marks = {80,91,92,93,94,95,};
		int totalMarks = 0;
		int projectMarks = 95; 
		for (int num : marks) {
			totalMarks = totalMarks + num;
		}
		totalMarks = totalMarks + projectMarks;
		int percentage = (totalMarks/marks.length) * 100;


		System.out.println(" Total Marks of a Graduate Student : " +totalMarks);	
		System.out.println(" Percentage of a Graduate Student : " +percentage);	

	}

	public BEGraduateStudent() {}

	public BEGraduateStudent(String stUniName) {
		super();
		this.stUniName = stUniName;
	}

	public BEGraduateStudent(int stRegNO, int stAge, String stFirstName, String stLastName, String stPlace) {
		super(stRegNO, stAge, stFirstName, stLastName, stPlace);
		// TODO Auto-generated constructor stub
	}

	public String getStUniName() {
		return stUniName;
	}

	public void setStUniName(String stUniName) {
		this.stUniName = stUniName;
	}



}




