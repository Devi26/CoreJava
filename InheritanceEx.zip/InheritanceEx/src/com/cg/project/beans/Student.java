package com.cg.project.beans;

public abstract class Student {
	private int stRegNO, stAge;
	private String stFirstName, stLastName, stPlace;
    
	public abstract void calStudentMarks();
	
	public Student() {}

	public Student(int stRegNO, int stAge, String stFirstName, String stLastName, String stPlace) {
		super();
		this.stRegNO = stRegNO;
		this.stAge = stAge;
		this.stFirstName = stFirstName;
		this.stLastName = stLastName;
		this.stPlace = stPlace;
	}

	public int getStRegNO() {
		return stRegNO;
	}

	public void setStRegNO(int stRegNO) {
		this.stRegNO = stRegNO;
	}

	public int getStAge() {
		return stAge;
	}

	public void setStAge(int stAge) {
		this.stAge = stAge;
	}

	public String getStFirstName() {
		return stFirstName;
	}

	public void setStFirstName(String stFirstName) {
		this.stFirstName = stFirstName;
	}

	public String getStLastName() {
		return stLastName;
	}

	public void setStLastName(String stLastName) {
		this.stLastName = stLastName;
	}

	public String getStPlace() {
		return stPlace;
	}

	public void setStPlace(String stPlace) {
		this.stPlace = stPlace;
	}
	
	
	
}