package com.cg.project.client;

import com.cg.project.beans.GraduateStudent;
import com.cg.project.beans.Student;

public class MainClass {

	public static void main(String[] args) {
	
		Student st;
		 st= new GraduateStudent(140269, 22, "Devi", "Ratnala", "Bhimavaram", "degree");
	}

}
