package com.cg.project.client;
import com.cg.project.beans.*;

public class MainClass {

	public static void main(String[] args) {

		/*Employee emp = new Employee(111, 30000, "Devi", "Ratnala");
		emp.calculateSalary();
		System.out.println(emp.getEmployeeId() + " " + emp.getFirstName() + " " + emp.getLastName() + " " + emp.getTotalSalary());

		PEmployee pemp = new PEmployee(112, 25000, "Surya", "Ratnala");
		pemp.calculateSalary();
		System.out.println(pemp.getEmployeeId() + " " + pemp.getFirstName() + " " + pemp.getLastName() + " " + pemp.getTotalSalary());

		CEmployee cemp = new CEmployee(113, "Sri", "Ratnala", 400);
		cemp.calculateSalary();
		cemp.signContract();
		System.out.println(cemp.getEmployeeId() + " " + cemp.getFirstName() + " " + cemp.getLastName() + " " + cemp.getTotalSalary());

		DevEmployee demp = new DevEmployee(114, 45000, "DEVI", "Ratnala", 2);
		demp.doAProject();
		demp.calculateSalary();
		System.out.println(demp.getEmployeeId() + " " + demp.getFirstName() + " " + demp.getLastName() + " " + demp.getTotalSalary());

		SalesEmployee semp = new SalesEmployee(115, 50000, "SURYA", "Ratnala", 10);
		semp.doSales();
		semp.calculateSalary();
		System.out.println(semp.getEmployeeId() + " " + semp.getFirstName() + " " + semp.getLastName() + " " + semp.getTotalSalary());
		*/
		
		Employee emp ;
		/*emp = new Employee(111, 30000, "Devi", "Ratnala");
		emp.calculateSalary();
		System.out.println(emp.getEmployeeId() + " " + emp.getFirstName() + " " + emp.getLastName() + " " + emp.getTotalSalary());*/
 
		emp =  new PEmployee(112, 25000, "Surya", "Ratnala");
		emp.calculateSalary();
		//System.out.println(emp.getEmployeeId() + " " + emp.getFirstName() + " " + emp.getLastName() + " " + emp.getTotalSalary());
		System.out.println(emp.toString());
		
		emp = new CEmployee(113, "Sri", "Ratnala", 400);
		
		CEmployee cemp = (CEmployee)emp;
		
		emp.calculateSalary();
		cemp.signContract();
		//System.out.println(cemp.getEmployeeId() + " " + cemp.getFirstName() + " " + cemp.getLastName() + " " + cemp.getTotalSalary());
		System.out.println(cemp.toString());
		
		emp = new DevEmployee(114, 45000, "DEVI", "Ratnala", 2);
		
		DevEmployee demp = (DevEmployee)emp;
		
		demp.doAProject();
		demp.calculateSalary();
	//	System.out.println(demp.getEmployeeId() + " " + demp.getFirstName() + " " + demp.getLastName() + " " + demp.getTotalSalary());
		System.out.println(demp.toString());
		
		emp = new SalesEmployee(115, 50000, "SURYA", "Ratnala", 10);
		
		SalesEmployee semp = (SalesEmployee)emp;
		
		semp.doSales();
		semp.calculateSalary();
		//System.out.println(semp.getEmployeeId() + " " + semp.getFirstName() + " " + semp.getLastName() + " " + semp.getTotalSalary());
		System.out.println(semp.toString());
		
		
	}


}
