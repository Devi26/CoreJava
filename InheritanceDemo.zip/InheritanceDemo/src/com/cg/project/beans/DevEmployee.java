package com.cg.project.beans;

public final class DevEmployee extends Employee{
	
	private int noOfProjectsDone, incentives;
	
	public void doAProject() {
		System.out.println("Projects Completed!");
	}
	
	public DevEmployee() {}

	
	public DevEmployee(int employeeId, int basicSalary, String firstName, String lastName, int noOfProjectsDone) {
		super(employeeId, basicSalary, firstName, lastName);
		this.noOfProjectsDone = noOfProjectsDone; 
	}

	public DevEmployee(int noOfProjectsDone, int incentives) {
		super();
		this.noOfProjectsDone = noOfProjectsDone;
		this.incentives = incentives;
	}
	
	
	public void setNoOfProjectsDone(int noOfProjectsDone) {
		this.noOfProjectsDone = noOfProjectsDone;
	}

	public int getIncentives() {
		return incentives;
	}

	public void setIncentives(int incentives) {
		this.incentives = incentives;
	}

	@Override
	public void calculateSalary() {
		incentives = noOfProjectsDone*3000;
		super.calculateSalary();
		this.setTotalSalary(this.getBasicSalary()+incentives);
		
	}

	@Override
	public String toString() {
		return super.toString() +"noOfProjectsDone=" + noOfProjectsDone + ", incentives=" + incentives ;
	}
	
	
	
	
}
