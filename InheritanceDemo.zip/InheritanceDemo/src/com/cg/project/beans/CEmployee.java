package com.cg.project.beans;

public final class CEmployee extends Employee {

	private int variablePay, hrs;
	
	public CEmployee() {}

	
	
	public CEmployee(int employeeId, String firstName, String lastName, int hrs) {
		super(employeeId, firstName, lastName);
		this.hrs=hrs;
	}



	public CEmployee(int variablePay, int hrs) {
		super();
		this.variablePay = variablePay;
		this.hrs = hrs;
	}
	

	public int getVariablePay() {
		return variablePay;
	}

	public void setVariablePay(int variablePay) {
		this.variablePay = variablePay;
	}

	public int getHrs() {
		return hrs;
	}

	public void setHrs(int hrs) {
		this.hrs = hrs;
	}

	public void calculateSalary() {

		variablePay = hrs*1000;
		this.setTotalSalary(+variablePay);
		
	}
	
	public void signContract() {
		
		System.out.println("Contract Signed!");
	}



	@Override
	public String toString() {
		return super.toString()+"variablePay=" + variablePay + ", hrs=" + hrs ;
	}
	
	
	
}
