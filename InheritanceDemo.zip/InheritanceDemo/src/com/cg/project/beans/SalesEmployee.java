package com.cg.project.beans;

public final class SalesEmployee extends Employee {
	private int noOfSales, commission;
	
	public void doSales() {
		System.out.println("Sales Completed......");
	}
	
    public SalesEmployee() {}

	public SalesEmployee(int employeeId, int basicSalary, String firstName, String lastName, int  noOfSales) {
		super(employeeId, basicSalary, firstName, lastName);
		this.noOfSales = noOfSales;
	}

	public SalesEmployee(int noOfSales, int commission) {
		super();
		this.noOfSales = noOfSales;
		this.commission = commission;
	}

	public int getNoOfSales() {
		return noOfSales;
	}

	public void setNoOfSales(int noOfSales) {
		this.noOfSales = noOfSales;
	}

	public int getCommission() {
		return commission;
	}

	public void setCommission(int commission) {
		this.commission = commission;
	}

	@Override
	public void calculateSalary() {
		commission = noOfSales * 2000;
		super.calculateSalary();
		this.setTotalSalary(this.getBasicSalary()+commission);
	}

	@Override
	public String toString() {
		return  super.toString() + " noOfSales=" + noOfSales + ", commission=" + commission ;
	}
	
	
	
}
