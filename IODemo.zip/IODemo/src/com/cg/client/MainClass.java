package com.cg.client;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import com.cg.iodemo.ObjectSerializationDemo;
import com.cg.iodemo.ReadWriteDemo;

public class MainClass {

	public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException  {
	/*	try {
			File file = new File("d:\\DataFile.txt");
			if(!file.exists())
				file.createNewFile();
			System.out.println(file.canWrite());
			System.out.println(file.getName());
			System.out.println(file.canExecute());
		} catch (IOException e) {
		e.printStackTrace();
		}*/
		
		File fromFile = new File("D:\\Users\\New folder\\JavaFile\\Factorial1111.java");
		File toFile = new File("d:\\" + fromFile.getName());
		try {
			//ReadWriteDemo.byteReadWriteDemo(fromFile, toFile);
			ReadWriteDemo.characterReadWrite(fromFile, toFile);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			File file = new File("D:\\Associate.txt");
			ObjectSerializationDemo.doSerialization(file);
			
			ObjectSerializationDemo.doDeSerialization(file);
		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		
	}

}
