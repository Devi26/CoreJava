package com.cg.atendencesystem.services;

import java.util.List;

import com.cg.atendencesystem.beans.CourseDetails;
import com.cg.atendencesystem.beans.ExamFeeDetails;
import com.cg.atendencesystem.beans.LectureDetails;
import com.cg.atendencesystem.beans.Student;
import com.cg.atendencesystem.exception.StudentDetailsNotFoundException;

public interface AttendenceSystemSevices {
	
	int acceptStudentDetails(String firstName, String lastName, int courseID, String courseName, String courseDuration,
			int noOfLecturesConducted, int noOfLecturesAttented, int examFeeToBePaid);
	
	int calculatePenality(int studentID) throws StudentDetailsNotFoundException;
	
	Student getStudentDetails(int studentID) throws StudentDetailsNotFoundException;
	
	List<Student> getAllStudentDetails();
	//Student[] getAllStudentDetails();

	int calculatePenalty(int studentID) throws StudentDetailsNotFoundException;
	
	

}
