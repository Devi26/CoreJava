package com.cg.atendencesystem.services;

import java.util.List;

import com.cg.atendencesystem.beans.CourseDetails;
import com.cg.atendencesystem.beans.ExamFeeDetails;
import com.cg.atendencesystem.beans.LectureDetails;
import com.cg.atendencesystem.beans.Student;
import com.cg.atendencesystem.daoservices.AttendenceSystemDAO;
import com.cg.atendencesystem.daoservices.AttendenceSystemDAOImpl;
import com.cg.atendencesystem.exception.StudentDetailsNotFoundException;

public class AttendenceSystemServicesImpl implements  AttendenceSystemSevices{
	
	AttendenceSystemDAO attendenceSystemDAO = new AttendenceSystemDAOImpl();

	@Override
	public int acceptStudentDetails(String firstName, String lastName, int courseID, String courseName,
			String courseDuration, int noOfLecturesConducted, int noOfLecturesAttented, int examFeeToBePaid) {
		
		Student  student = new Student(firstName, lastName, new CourseDetails(courseID, courseName, courseDuration), new LectureDetails(noOfLecturesConducted, noOfLecturesAttented), new ExamFeeDetails(examFeeToBePaid));
		student = attendenceSystemDAO.save(student);
		return student.getStudentID();
	}

	@Override
	public int calculatePenalty(int studentID) throws StudentDetailsNotFoundException {
		
		Student student = new Student(studentID);
		student = this.getStudentDetails(studentID);
		attendenceSystemDAO.update(student);
		
		student.getExamFeeDetails();
		
		
			
		return 0;
	}

	@Override
	public Student getStudentDetails(int studentID) throws StudentDetailsNotFoundException {
		Student student=attendenceSystemDAO.findOne(studentID);
		if(student==null)	throw new  StudentDetailsNotFoundException("Student Id is not found"+studentID);
		return student;
	}

	@Override
	public List<Student> getAllStudentDetails(){
		List<Student> listOfStudents = attendenceSystemDAO.findAll();
		 return listOfStudents;
		
	}
	
	/*public Student [] getAllStudentDetails() {
	
		//return AttendenceSystemUtil.students;
	}*/

	@Override
	public int calculatePenality(int studentID) throws StudentDetailsNotFoundException {
		// TODO Auto-generated method stub
		return 0;
	}

}
 