package com.cg.atendencesystem.daoservices;

import java.util.List;

import com.cg.atendencesystem.beans.Student;

public interface AttendenceSystemDAO {
	 
	Student save(Student student);
	boolean update(Student student);
	Student findOne(int studentID);
	List<Student> findAll();
	//Student [] findAll();

}
