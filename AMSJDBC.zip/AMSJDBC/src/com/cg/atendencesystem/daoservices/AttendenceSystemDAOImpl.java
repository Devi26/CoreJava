package com.cg.atendencesystem.daoservices;

import java.util.ArrayList;
import java.util.List;

import com.cg.atendencesystem.beans.Student;

public class AttendenceSystemDAOImpl implements  AttendenceSystemDAO {

	@Override
	public Student save(Student student) {
		return null;
	}

	@Override
	public boolean update(Student student) {
		return false;
	}

	@Override
	public Student findOne(int studentID) {
		return null;
	}

	@Override
	public List<Student> findAll() {
		return null;
	}

	
}
