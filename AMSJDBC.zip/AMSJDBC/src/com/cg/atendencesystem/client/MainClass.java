package com.cg.atendencesystem.client;

import com.cg.atendencesystem.beans.Student;
import com.cg.atendencesystem.exception.StudentDetailsNotFoundException;
import com.cg.atendencesystem.services.AttendenceSystemServicesImpl;
import com.cg.atendencesystem.services.AttendenceSystemSevices;
import com.cg.atendencesystem.util.DBUtil;

public class MainClass {

	public static void main(String[] args) {
		DBUtil dbUtil = new DBUtil();
		dbUtil.getDBConnection();
		System.out.println("Devi Connection has Opened....");
	}
}
