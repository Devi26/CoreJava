package com.cg.atendencesystem.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBUtil {
	private static Connection con;
		public static Connection getDBConnection()  {
			try {
				if(con == null) {
					Properties dbproperties = new  Properties();
					 dbproperties.load(new FileInputStream(new  File(".\\resources\\amsjdbc.properties")));
					 String driver = dbproperties.getProperty("driver");
					 String url = dbproperties.getProperty("url");
					 String user = dbproperties.getProperty("user");
					 String password = dbproperties.getProperty("password");	 
					 Class.forName(driver);
					 con = DriverManager.getConnection(url, user, password);
				}
			} catch (ClassNotFoundException | IOException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return con;	
		}
}
