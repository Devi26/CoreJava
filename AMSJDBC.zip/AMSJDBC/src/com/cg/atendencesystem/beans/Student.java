package com.cg.atendencesystem.beans;

public class Student {

	private int studentID;
	private String firstName, lastName;
	private CourseDetails courseDetails;
	private LectureDetails lectureDetails;
	private ExamFeeDetails examFeeDetails;
	
	public Student() {}

	public Student(int studentID) {
		super();
		this.studentID = studentID;
	}

	public Student(String firstName, String lastName, CourseDetails courseDetails, LectureDetails lectureDetails,
			ExamFeeDetails examFeeDetails) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.courseDetails = courseDetails;
		this.lectureDetails = lectureDetails;
		this.examFeeDetails = examFeeDetails;
	}

	public Student(int studentID, String firstName, String lastName, CourseDetails courseDetails,
			LectureDetails lectureDetails, ExamFeeDetails examFeeDetails) {
		super();
		this.studentID = studentID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.courseDetails = courseDetails;
		this.lectureDetails = lectureDetails;
		this.examFeeDetails = examFeeDetails;
	}

	public int getStudentID() {
		return studentID;
	}

	public void setStudentID(int studentID) {
		this.studentID = studentID;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public CourseDetails getCourseDetails() {
		return courseDetails;
	}

	public void setCourseDetails(CourseDetails courseDetails) {
		this.courseDetails = courseDetails;
	}

	public LectureDetails getLectureDetails() {
		return lectureDetails;
	}

	public void setLectureDetails(LectureDetails lectureDetails) {
		this.lectureDetails = lectureDetails;
	}

	public ExamFeeDetails getExamFeeDetails() {
		return examFeeDetails;
	}

	public void setExamFeeDetails(ExamFeeDetails examFeeDetails) {
		this.examFeeDetails = examFeeDetails;
	}
	
	
	
	
}
