package com.cg.atendencesystem.beans;

public class LectureDetails {

	private int noOfLecturesConducted, noOfLecturesAttented, noOfSubjects;

	public LectureDetails() {}
	
	public LectureDetails(int noOfLecturesConducted, int noOfLecturesAttented) {
		super();
		this.noOfLecturesConducted = noOfLecturesConducted;
		this.noOfLecturesAttented = noOfLecturesAttented;
	}

	public LectureDetails(int noOfLecturesConducted, int noOfLecturesAttented, int noOfSubjects) {
		super();
		this.noOfLecturesConducted = noOfLecturesConducted;
		this.noOfLecturesAttented = noOfLecturesAttented;
		this.noOfSubjects = noOfSubjects;
	}

	public int getNoOfLecturesConducted() {
		return noOfLecturesConducted;
	}

	public void setNoOfLecturesConducted(int noOfLecturesConducted) {
		this.noOfLecturesConducted = noOfLecturesConducted;
	}

	public int getNoOfLecturesAttented() {
		return noOfLecturesAttented;
	}

	public void setNoOfLecturesAttented(int noOfLecturesAttented) {
		this.noOfLecturesAttented = noOfLecturesAttented;
	}

	public int getNoOfSubjects() {
		return noOfSubjects;
	}

	public void setNoOfSubjects(int noOfSubjects) {
		this.noOfSubjects = noOfSubjects;
	}


}
