package com.cg.atendencesystem.beans;

public class ExamFeeDetails {
	
	private int penaltyToBePaid, examFeeToBePaid, totalExamFeeToBePaid;
	private int penalty, attendencePerctge;
	
	public ExamFeeDetails() {}

	public ExamFeeDetails(int examFeeToBePaid) {
		super();
		this.examFeeToBePaid = examFeeToBePaid;
	}
	
	public ExamFeeDetails(int penaltyToBePaid, int examFeeToBePaid, int totalExamFeeToBePaid) {
		super();
		this.penaltyToBePaid = penaltyToBePaid;
		this.examFeeToBePaid = examFeeToBePaid;
		this.totalExamFeeToBePaid = totalExamFeeToBePaid;
	}

	public int getPenaltyToBePaid() {
		return penaltyToBePaid;
	}

	public void setPenaltyToBePaid(int penaltyToBePaid) {
		this.penaltyToBePaid = penaltyToBePaid;
	}

	public int getExamFeeToBePaid() {
		return examFeeToBePaid;
	}

	public void setExamFeeToBePaid(int examFeeToBePaid) {
		this.examFeeToBePaid = examFeeToBePaid;
	}

	public int getTotalExamFeeToBePaid() {
		return totalExamFeeToBePaid;
	}

	public void setTotalExamFeeToBePaid(int totalExamFeeToBePaid) {
		this.totalExamFeeToBePaid = totalExamFeeToBePaid;
	}
	
	
	
	

}
