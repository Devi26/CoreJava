package com.cg.atendencesystem.beans;

public class CourseDetails {

	private int courseID;
	private String courseName, courseDuration;
	
	public CourseDetails() {}

	public CourseDetails(int courseID, String courseName, String courseDuration) {
		super();
		this.courseID = courseID;
		this.courseName = courseName;
		this.courseDuration = courseDuration;
	}

	public int getCourseID() {
		return courseID;
	}

	public void setCourseID(int courseID) {
		this.courseID = courseID;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public String getCourseDuration() {
		return courseDuration;
	}

	public void setCourseDuration(String courseDuration) {
		this.courseDuration = courseDuration;
	}
	
	
}
