package com.cg.project.beans1;

public class SalesEmployee1 extends Employee1{

	private int noOfSales, commission;
	
	public void doSales() {
		System.out.println("Sales Completed...................");
	}

	public SalesEmployee1(int employeeId, int basicSalary, String firstName, String lastName, int noOfSales) {
		super(employeeId, basicSalary, firstName, lastName);
		this.noOfSales = noOfSales;
	}

	public SalesEmployee1(int noOfSales, int commission) {
		super();
		this.noOfSales = noOfSales;
		this.commission = commission;
	}

	public int getNoOfSales() {
		return noOfSales;
	}

	public void setNoOfSales(int noOfSales) {
		this.noOfSales = noOfSales;
	}

	public int getCommission() {
		return commission;
	}

	public void setCommission(int commission) {
		this.commission = commission;
	}

	@Override
	public void calculateSalary() {
		super.calculateSalary();
		noOfSales = noOfSales * 2000;
		this.setTotalSalary(this.getBasicSalary() + noOfSales);
	}
	
	
	
	
	
}
