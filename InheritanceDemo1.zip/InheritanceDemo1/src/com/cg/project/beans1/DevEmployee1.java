package com.cg.project.beans1;

public class DevEmployee1 extends Employee1 {

	private int noOfProjectsDone, incentives;
	
	public void doProjects() {
		System.out.println("Done with Projects");
	}
	
	public DevEmployee1() {}

	public DevEmployee1(int employeeId, int basicSalary, String firstName, String lastName, int noOfProjectsDone) {
		super(employeeId, basicSalary, firstName, lastName);
		this.noOfProjectsDone = noOfProjectsDone;

	}

	public DevEmployee1(int noOfProjectsDone, int incentives) {
		super();
		this.noOfProjectsDone = noOfProjectsDone;
		this.incentives = incentives;
	}

	public int getNoOfProjectsDone() {
		return noOfProjectsDone;
	}

	public void setNoOfProjectsDone(int noOfProjectsDone) {
		this.noOfProjectsDone = noOfProjectsDone;
	}

	public int getIncentives() {
		return incentives;
	}

	public void setIncentives(int incentives) {
		this.incentives = incentives;
	}

	@Override
	public void calculateSalary() {
		
		super.calculateSalary();
		
		incentives = noOfProjectsDone * 2000;
		this.setTotalSalary(this.getBasicSalary()+incentives);
	}
	
	
	
}
