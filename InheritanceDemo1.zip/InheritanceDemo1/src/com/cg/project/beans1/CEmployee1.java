package com.cg.project.beans1;

public class CEmployee1 extends Employee1 {
	private int variablePay, hrs;
	 
	public void signProjects() {
		 System.out.println("Projects Sined");
	 }
	
	public CEmployee1(int employeeId, String firstName, String lastName, int hrs) {
		super(employeeId, firstName, lastName);
		this.hrs = hrs;
	}

	public CEmployee1() {}

	public CEmployee1(int variablePay, int hrs) {
		super();
		this.variablePay = variablePay;
		this.hrs = hrs;
	}

	public int getVariablePay() {
		return variablePay;
	}

	public void setVariablePay(int variablePay) {
		this.variablePay = variablePay;
	}

	public int getHrs() {
		return hrs;
	}

	public void setHrs(int hrs) {
		this.hrs = hrs;
	}

	@Override
	public void calculateSalary() {
		
		super.calculateSalary();
		
		variablePay = hrs * 1000;
		this.setTotalSalary(variablePay);
	}
	
	
	
}
