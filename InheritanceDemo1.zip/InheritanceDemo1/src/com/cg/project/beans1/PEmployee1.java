package com.cg.project.beans1;

public class PEmployee1 extends Employee1 {

	private int hra, ta, da;
	
	public PEmployee1() {}

	public PEmployee1(int employeeId, int basicSalary, String firstName, String lastName) {
		super(employeeId, basicSalary, firstName, lastName);
	}

	public PEmployee1(int hra, int ta, int da) {
		super();
		this.hra = hra;
		this.ta = ta;
		this.da = da;
	}

	public int getHra() {
		return hra;
	}

	public void setHra(int hra) {
		this.hra = hra;
	}

	public int getTa() {
		return ta;
	}

	public void setTa(int ta) {
		this.ta = ta;
	}

	public int getDa() {
		return da;
	}

	public void setDa(int da) {
		this.da = da;
	}

	
	public void calculateSalary() {
		
		hra = this.getBasicSalary()*10/100;
		ta = this.getBasicSalary()*10/100;
		da = this.getBasicSalary()*10/100;
	
	this.setTotalSalary(this.getBasicSalary()+hra+ta+da);
	}
	
}
