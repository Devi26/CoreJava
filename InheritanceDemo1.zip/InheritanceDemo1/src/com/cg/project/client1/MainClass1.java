package com.cg.project.client1;

import com.cg.project.beans1.CEmployee1;
import com.cg.project.beans1.DevEmployee1;
import com.cg.project.beans1.Employee1;
import com.cg.project.beans1.PEmployee1;
import com.cg.project.beans1.SalesEmployee1;

public class MainClass1 {

	public static void main(String[] args) {
	
		Employee1 emp1 = new Employee1(1111, 40000, "DEVI", "Ratnala");
		emp1.calculateSalary();
		System.out.println(emp1.getEmployeeId() + "  " + emp1.getBasicSalary() + " " + emp1.getFirstName() + " " + emp1.getLastName());
	
		PEmployee1 pemp1 = new PEmployee1(1112, 50000, "SURYA", "RATNALA");
		pemp1.calculateSalary();
		System.out.println(pemp1.getEmployeeId() + "  " + pemp1.getTotalSalary() + " " + pemp1.getFirstName() + " " + pemp1.getLastName());
	
		CEmployee1 cemp1 = new CEmployee1(1113, "SRI", "RATNALA", 300);
		cemp1.signProjects();
		cemp1.calculateSalary();
		System.out.println(cemp1.getEmployeeId() +" "+ cemp1.getHrs()  +"  " + cemp1.getTotalSalary() + " " + cemp1.getFirstName() + " " + cemp1.getLastName());
	
		DevEmployee1 demp1 = new DevEmployee1(1114, 60000, "Devi", "Ratnala", 5);
		demp1.doProjects();
		demp1.calculateSalary();
		System.out.println(demp1.getEmployeeId() +" "+ demp1.getNoOfProjectsDone() +"  " + demp1.getTotalSalary() + " " + demp1.getFirstName() + " " + demp1.getLastName());
	
		SalesEmployee1 semp1  =new SalesEmployee1(1115, 70000, "Surya", "Ratnala", 4);
		semp1.doSales();
		semp1.calculateSalary();
		System.out.println(semp1.getEmployeeId() +" "+ semp1.getNoOfSales()  +"  " + semp1.getTotalSalary() + " " + semp1.getFirstName() + " " + semp1.getLastName());
		
	}

}
