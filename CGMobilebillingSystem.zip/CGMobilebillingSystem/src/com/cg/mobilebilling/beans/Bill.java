package com.cg.mobilebilling.beans;

public class Bill {

	private int billID, noOfLocalSMS, noOfLocalStdSMS, noOfLocalCalls, noOfStdCalls, internetDataUsageUnits;
	private float internetDataUsageUnitsAmount, billMonth, stateGST, centralGST, totalBillAmount, localSMSAmount, stdSMSAmount, localCallAmount;

	public Bill() {
		// TODO Auto-generated constructor stub
	}

	public int getBillID() {
		return billID;
	}

	public void setBillID(int billID) {
		this.billID = billID;
	}

	public int getNoOfLocalSMS() {
		return noOfLocalSMS;
	}

	public void setNoOfLocalSMS(int noOfLocalSMS) {
		this.noOfLocalSMS = noOfLocalSMS;
	}

	public int getNoOfLocalStdSMS() {
		return noOfLocalStdSMS;
	}

	public void setNoOfLocalStdSMS(int noOfLocalStdSMS) {
		this.noOfLocalStdSMS = noOfLocalStdSMS;
	}

	public int getNoOfLocalCalls() {
		return noOfLocalCalls;
	}

	public void setNoOfLocalCalls(int noOfLocalCalls) {
		this.noOfLocalCalls = noOfLocalCalls;
	}

	public int getNoOfStdCalls() {
		return noOfStdCalls;
	}

	public void setNoOfStdCalls(int noOfStdCalls) {
		this.noOfStdCalls = noOfStdCalls;
	}

	public int getInternetDataUsageUnits() {
		return internetDataUsageUnits;
	}

	public void setInternetDataUsageUnits(int internetDataUsageUnits) {
		this.internetDataUsageUnits = internetDataUsageUnits;
	}

	public float getInternetDataUsageUnitsAmount() {
		return internetDataUsageUnitsAmount;
	}

	public void setInternetDataUsageUnitsAmount(float internetDataUsageUnitsAmount) {
		this.internetDataUsageUnitsAmount = internetDataUsageUnitsAmount;
	}

	public float getBillMonth() {
		return billMonth;
	}

	public void setBillMonth(float billMonth) {
		this.billMonth = billMonth;
	}

	public float getStateGST() {
		return stateGST;
	}

	public void setStateGST(float stateGST) {
		this.stateGST = stateGST;
	}

	public float getCentralGST() {
		return centralGST;
	}

	public void setCentralGST(float centralGST) {
		this.centralGST = centralGST;
	}

	public float getTotalBillAmount() {
		return totalBillAmount;
	}

	public void setTotalBillAmount(float totalBillAmount) {
		this.totalBillAmount = totalBillAmount;
	}

	public float getLocalSMSAmount() {
		return localSMSAmount;
	}

	public void setLocalSMSAmount(float localSMSAmount) {
		this.localSMSAmount = localSMSAmount;
	}

	public float getStdSMSAmount() {
		return stdSMSAmount;
	}

	public void setStdSMSAmount(float stdSMSAmount) {
		this.stdSMSAmount = stdSMSAmount;
	}

	public float getLocalCallAmount() {
		return localCallAmount;
	}

	public void setLocalCallAmount(float localCallAmount) {
		this.localCallAmount = localCallAmount;
	}


}
