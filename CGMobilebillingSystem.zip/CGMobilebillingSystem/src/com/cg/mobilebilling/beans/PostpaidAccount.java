package com.cg.mobilebilling.beans;

public class PostpaidAccount {
	private int mobileNo;

	public PostpaidAccount() {
		// TODO Auto-generated constructor stub
	}

	public int getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}



}
