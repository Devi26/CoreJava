
public class Sample {
	
	int a;
	int b;
 
	public static int c ;

	public Sample(int a, int b) {
		super();
		this.a = a;
		this.b = b;
		
	}
	public void display() {
		a++;
		b++;
		c++;
		
		System.out.println(a + " " + b + " " + c );
	}


public static void main(String[] args) {
		
	
	Sample s  = new Sample(100,200);
	Sample s1  = new Sample(300,400);
	Sample s2  = new Sample(500,600);
	s.display();
	s1.display();
	s2.display();

	}
}
