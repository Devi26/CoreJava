package com.cg.payroll.beans;

public class Salary {
	private int basicSalary, epf, companyPf;
	private int hra, conveyanceAllowance, otherAllowance, personalAllowance, monthlyGrossSalary, annualGrossSalary, netSalary;
	int monthlyTax, yearlyTax;

	public Salary() {
		// TODO Auto-generated constructor stub
	}
	

	public Salary(int basicSalary, int epf, int companyPf) {
		super();
		this.basicSalary = basicSalary;
		this.epf = epf;
		this.companyPf = companyPf;
	}

	
	
	public Salary(int hra, int conveyanceAllowance, int otherAllowance, int personalAllowance, int monthlyGrossSalary,
			int annualGrossSalary, int netSalary, int monthlyTax, int yearlyTax) {
		super();
		this.hra = hra;
		this.conveyanceAllowance = conveyanceAllowance;
		this.otherAllowance = otherAllowance;
		this.personalAllowance = personalAllowance;
		this.monthlyGrossSalary = monthlyGrossSalary;
		this.annualGrossSalary = annualGrossSalary;
		this.netSalary = netSalary;
		this.monthlyTax = monthlyTax;
		this.yearlyTax = yearlyTax;
	}


	public int getBasicSalary() {
		return basicSalary;
	}

	public void setBasicSalary(int basicSalary) {
		this.basicSalary = basicSalary;
	}

	public int getEpf() {
		return epf;
	}

	public void setEpf(int epf) {
		this.epf = epf;
	}

	public int getCompanyPf() {
		return companyPf;
	}

	public void setCompanyPf(int companyPf) {
		this.companyPf = companyPf;
	}

	public int getHra() {
		return hra;
	}

	public void setHra(int hra) {
		this.hra = hra;
	}

	public int getConveyanceAllowance() {
		return conveyanceAllowance;
	}

	public void setConveyanceAllowance(int conveyanceAllowance) {
		this.conveyanceAllowance = conveyanceAllowance;
	}

	public int getOtherAllowance() {
		return otherAllowance;
	}

	public void setOtherAllowance(int otherAllowance) {
		this.otherAllowance = otherAllowance;
	}

	public int getPersonalAllowance() {
		return personalAllowance;
	}

	public void setPersonalAllowance(int personalAllowance) {
		this.personalAllowance = personalAllowance;
	}

	public int getMonthlyGrossSalary() {
		return monthlyGrossSalary;
	}

	public void setMonthlyGrossSalary(int monthlyGrossSalary) {
		this.monthlyGrossSalary = monthlyGrossSalary;
	}

	public int getAnnualGrossSalary() {
		return annualGrossSalary;
	}

	public void setAnnualGrossSalary(int annualGrossSalary) {
		this.annualGrossSalary = annualGrossSalary;
	}

	public int getNetSalary() {
		return netSalary;
	}

	public void setNetSalary(int netSalary) {
		this.netSalary = netSalary;
	}

	public int getMonthlyTax() {
		return monthlyTax;
	}

	public void setMonthlyTax(int monthlyTax) {
		this.monthlyTax = monthlyTax;
	}

	public int getYearlyTax() {
		return yearlyTax;
	}

	public void setYearlyTax(int yearlyTax) {
		this.yearlyTax = yearlyTax;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + annualGrossSalary;
		result = prime * result + basicSalary;
		result = prime * result + companyPf;
		result = prime * result + conveyanceAllowance;
		result = prime * result + epf;
		result = prime * result + hra;
		result = prime * result + monthlyGrossSalary;
		result = prime * result + monthlyTax;
		result = prime * result + netSalary;
		result = prime * result + otherAllowance;
		result = prime * result + personalAllowance;
		result = prime * result + yearlyTax;
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Salary other = (Salary) obj;
		if (annualGrossSalary != other.annualGrossSalary)
			return false;
		if (basicSalary != other.basicSalary)
			return false;
		if (companyPf != other.companyPf)
			return false;
		if (conveyanceAllowance != other.conveyanceAllowance)
			return false;
		if (epf != other.epf)
			return false;
		if (hra != other.hra)
			return false;
		if (monthlyGrossSalary != other.monthlyGrossSalary)
			return false;
		if (monthlyTax != other.monthlyTax)
			return false;
		if (netSalary != other.netSalary)
			return false;
		if (otherAllowance != other.otherAllowance)
			return false;
		if (personalAllowance != other.personalAllowance)
			return false;
		if (yearlyTax != other.yearlyTax)
			return false;
		return true;
	}


	@Override
	public String toString() {
		return "Salary [basicSalary=" + basicSalary + ", epf=" + epf + ", companyPf=" + companyPf + ", hra=" + hra
				+ ", conveyanceAllowance=" + conveyanceAllowance + ", otherAllowance=" + otherAllowance
				+ ", personalAllowance=" + personalAllowance + ", monthlyGrossSalary=" + monthlyGrossSalary
				+ ", annualGrossSalary=" + annualGrossSalary + ", netSalary=" + netSalary + ", monthlyTax=" + monthlyTax
				+ ", yearlyTax=" + yearlyTax + "]";
	}

	
	
}
