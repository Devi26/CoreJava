package com.cg.payroll.test;

import java.util.ArrayList;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exception.AssociateDetailsNotFoundException;
import com.cg.payroll.exception.InvalidEmailException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.util.PayrollUtil;

public class PayrollServicesTest {
	static PayrollServices payrollServices;

	@BeforeClass
	public static void setUpTestEnv() {
		payrollServices = new PayrollServicesImpl();
	}
	
	@Before
	public void setUpTestData() {
		
	Associate associate1 = new Associate(101, 78000, "Devi", "Ratnala", "IT", "Analyst", "BXGPR6235Q", "dssri.26@gmail.com", new Salary(35000, 1800, 1800), new BankDetails(14567, "ICICI", "IVIC006I"));
	Associate associate2 = new Associate(102, 78000, "Devi", "Ratnala", "IT", "Analyst", "BXGPR6235Q", "dssri.26@gmail.com", new Salary(35000, 1800, 1800), new BankDetails(14567, "ICICI", "IVIC006I"));
	PayrollUtil.associates.put(associate1.getAssociateID(), associate1);
	PayrollUtil.associates.put(associate2.getAssociateID(), associate2);
	PayrollUtil.ASSOCIATE_ID_COUNTER = 102;
	}
	
	@Test
	public void testAcceptAssociateDetailsForValidData() throws InvalidEmailException {
		int expectedAssociateId = 103;
		int actualAssociateId = payrollServices.acceptAssociateDetails(90000, "Devi", "Ratnala", "IT", "Analyst", "BXGPR6235Q", "dssri.26@gmail.com", 35000, 1800, 1800, 14567, "ICICI", "IVIC006I");
		Assert.assertEquals(expectedAssociateId, actualAssociateId);
	}
	
	@Test
	public void testCalculateNetSalaryForValidData() throws AssociateDetailsNotFoundException {
		int expectedAns = 30800 ;
		int actualAns = payrollServices.calculateNetSalary(101);
		Assert.assertEquals(expectedAns, actualAns);
	}
	
	 @Test(expected=AssociateDetailsNotFoundException.class)
	    public void testCalculateNetSalaryForInvalidAssociate() throws AssociateDetailsNotFoundException {
	        int actualNetSalary=payrollServices.calculateNetSalary(122);
	            }
	
	@Test(expected = AssociateDetailsNotFoundException.class)
	public void testGetAssociateDataForInvalidAssociateId() throws AssociateDetailsNotFoundException {
		payrollServices.getAssociateDetails(135);
	}
	
	@Test
	public void testGetAssociateDataForValidAssociateId() throws AssociateDetailsNotFoundException{
		Associate expectedAssociate = new Associate(102, 78000, "Devi", "Ratnala", "IT", "Analyst", "BXGPR6235Q", "dssri.26@gmail.com", new Salary(35000, 1800, 1800), new BankDetails(14567, "ICICI", "IVIC006I"));
	
		Associate actualAssociate = payrollServices.getAssociateDetails(102);
		
		Assert.assertEquals(expectedAssociate, actualAssociate);
	}
	
	@Test
    public void testGetAllDetailsForValidAssociate() {
        ArrayList<Associate> expectedAllDetails=new ArrayList<>();
        expectedAllDetails.add(new Associate(101,6000, "Tharani", "Bose", "IT", "analyst", "FHA612GF", "thara@gmail.com", new Salary(6000, 1500, 1200), new BankDetails(121324325, "HDFC", "hdfc26564g")));
        expectedAllDetails.add(new Associate(102,2000, "Karthiyayini", "P", "IT", "Data Analyst", "AF60154KL", "karthi@gmail.com", new Salary(5000, 1500, 1200), new BankDetails(13001212, "HDFC", "hdfc30458g")));
        ArrayList<Associate>actualAllDetails=(ArrayList<Associate>) payrollServices.getallAssociateDetails();
        Assert.assertEquals(expectedAllDetails, actualAllDetails);
    }
	
	
	@After
	public void tearDownTestData() {
		PayrollUtil.ASSOCIATE_ID_COUNTER = 100;
		PayrollUtil.associates.clear();
		
	}
	
	@AfterClass
	public static void tearDownTestEnv() {
		payrollServices = null;
	}
	
	/*@Test
	void test() {
		fail("Not yet implemented");
	}*/

}
