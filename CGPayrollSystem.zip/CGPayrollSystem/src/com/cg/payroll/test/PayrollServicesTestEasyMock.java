package com.cg.payroll.test;
import java.util.ArrayList;
import java.util.List;

import org.easymock.EasyMock;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.exception.AssociateDetailsNotFoundException;
import com.cg.payroll.exception.InvalidEmailException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

public class PayrollServicesTestEasyMock {
	
	private static PayrollServices payrollServices ;
	private static AssociateDAO mockAssociateDao;
	
	@BeforeClass
	public static void setUpTestEnv() {
		mockAssociateDao = EasyMock.mock(AssociateDAO.class);
		payrollServices = new PayrollServicesImpl(mockAssociateDao);
	}
	
	@Before
	public void setUpTestMockData() {
		Associate associate1 = new Associate(101, 78000, "Devi", "Ratnala", "It", "Analyst", "BXGPR6235Q", "dssri.26@gmail.com", new Salary(35000, 1800, 1800), new BankDetails(14567, "ICICI", "IVIC006I"));
		Associate associate2 = new Associate(102, 80000, "Surya", "Ratnala", "IT", "Analyst", "BXGPR6235Q", "dssri.26@gmail.com", new Salary(35000, 1800, 1800), new BankDetails(14567, "ICICI", "IVIC006I"));
		Associate associate3 = new Associate(90000, "Sri", "Ratnala", "It", "Analyst", "BXGPR6235Q", "dssri.26@gmail.com", new Salary(35000, 1800, 1800), new BankDetails(14567, "ICICI", "IVIC006I"));
		
		ArrayList<Associate> associateList = new ArrayList<>();
		associateList.add(associate1);
		associateList.add(associate2);
		
		EasyMock.expect(mockAssociateDao.save(associate3)).andReturn(associate3);
	
		EasyMock.expect(mockAssociateDao.findOne(101)).andReturn(associate1);
		EasyMock.expect(mockAssociateDao.findOne(102)).andReturn(associate2);
		EasyMock.expect(mockAssociateDao.findOne(10677)).andReturn(null);
		
		EasyMock.expect(mockAssociateDao.findAll()).andReturn(associateList);		
	
		EasyMock.replay(mockAssociateDao);
		
	}

	@Test(expected = AssociateDetailsNotFoundException.class)
	public void testGetAssociateDetailsForInvalidAssociateId() throws AssociateDetailsNotFoundException{
		payrollServices.getAssociateDetails(12355);
		EasyMock.verify(mockAssociateDao.findOne(1235));
	}
	
	@Test
	public void testGetAssociateDetailsForValidAssociateId() throws AssociateDetailsNotFoundException {
		Associate expectedAssociateDetails = new Associate(101, 78000, "Devi", "Ratnala", "It", "Analyst", "BXGPR6235Q", "dssri.26@gmail.com", new Salary(35000, 1800, 1800), new BankDetails(14567, "ICICI", "IVIC006I"));
		Associate actualAssociateDetails = payrollServices.getAssociateDetails(101);
	
		Assert.assertEquals(expectedAssociateDetails, actualAssociateDetails);	
		//EasyMock.verify(mockAssociateDao.findOne(101));
	}
	
	@Test
	public void testAcceptAssociateDetails() throws InvalidEmailException {
		Associate associate3 = new  Associate(90000, "Sri", "Ratnala", "It", "Analyst", "BXGPR6235Q", "dssri.26@gmail.com", new Salary(35000, 1800, 1800), new BankDetails(14567, "ICICI", "IVIC006I"));
		 payrollServices.acceptAssociateDetails(90000, "Ratnala", "Ratnala", "IT", "analyst", "BXGPR6235", "dssri.26@gmail.com", 25000, 2000, 3500, 1237338, "ICICI", "ICIC07");
		EasyMock.verify(mockAssociateDao.save(associate3));
	
	}
	
	@Test
	public void testGetAlltAssociateDetails() {
		List<Associate> actualListOfAllAssociateDetails = new ArrayList<>();
		actualListOfAllAssociateDetails = payrollServices.getallAssociateDetails();
		ArrayList<Associate> expectedListOfAllAssociateDetails = new ArrayList<>();
		expectedListOfAllAssociateDetails.add(new Associate(101, 78000, "Devi", "Ratnala", "It", "Analyst", "BXGPR6235Q", "dssri.26@gmail.com", new Salary(35000, 1800, 1800), new BankDetails(14567, "ICICI", "IVIC006I")));
		expectedListOfAllAssociateDetails.add(new Associate(102, 78000, "Devi", "Ratnala", "It", "Analyst", "BXGPR6235Q", "dssri.26@gmail.com", new Salary(35000, 1800, 1800), new BankDetails(14567, "ICICI", "IVIC006I")));
		Assert.assertEquals(expectedListOfAllAssociateDetails, actualListOfAllAssociateDetails);
	}
	
	/*@Test
	public void testCalculateNetSalary() {
		Associate associate = new Associate(101, 78000, "Devi", "Ratnala", "It", "Analyst", "BXGPR6235Q", "dssri.26@gmail.com", new Salary(35000, 1800, 1800), new BankDetails(14567, "ICICI", "IVIC006I"));
		payrollServices.calculateNetSalary(101);
		
	
	} */
	
	@After
	public void tearDownTestMockData() {
		EasyMock.reset(mockAssociateDao);
	}
	
	
	@AfterClass
	public static void tearDownTestEnv() {
		mockAssociateDao = null;
		payrollServices = null;
	}

}
