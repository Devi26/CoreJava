package com.cg.payroll.daoservices;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.util.PayrollUtil;

public class AssociateDAOImpl implements AssociateDAO {

	@Override
	public Associate save(Associate associate) {

		associate.setAssociateID(PayrollUtil.getASSOCIATE_ID_COUNTER());

		// PayrollUtil.associates[PayrollUtil.getASSOCIATE_IDX()] = associate;

		PayrollUtil.associates.put(associate.getAssociateID(), associate); //Map
		//PayrollUtil.associates.add(associate.getAssociateID());
		return associate;

	}

	@Override
	public boolean update(Associate associate) {

		PayrollUtil.associates.put(associate.getAssociateID(), associate);
		return true;
		// PayrollUtil.associates.

		// return false;
	}

	@Override
	public Associate findOne(int associateId) {

		return PayrollUtil.associates.get(associateId);

		/*
		 * for (Associate associate : PayrollUtil.associates) if(associate != null &&
		 * associate.getAssociateID() == associateId) return associate; return null;
		 */

	}

	@Override
	public List<Associate> findAll() {

		return new ArrayList<>(PayrollUtil.associates.values());
		 //return new ArrayList<>(PayrollUtil.associates.values()); //Map
		//return new ArrayList<Associate>(PayrollUtil.associates); //Set
		/*
		 * ArrayList<Associate> associateList = new ArrayList<>(); Set<Integer> keySet =
		 * PayrollUtil.associates.keySet(); for (Integer key : keySet) {
		 * associateList.add(PayrollUtil.associates.get(key)); }
		 */

		/*
		 * ArrayList<Associate> associateList = (ArrayList<Associate>)
		 * PayrollUtil.associates.values(); /*
		 * 
		 * 
		 * /*public Associate[] findAll() {
		 * 
		 * 
		 * TODO Auto-generated method stub return PayrollUtil.associates;
		 */

	}

	@Override
	public boolean removeAssociate(int associateId) {
		if (PayrollUtil.associates.containsKey(associateId)) {//Map
			PayrollUtil.associates.remove(associateId);
			return true;
		} else
			return false;
	/*	if(PayrollUtil.associates.contains(associateId)) {
			PayrollUtil.associates.remove(associateId);
			return true;
		}else 
			return false;
		}*/
	}
}


