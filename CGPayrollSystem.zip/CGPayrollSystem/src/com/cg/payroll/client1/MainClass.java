package com.cg.payroll.client1;
import java.util.Scanner;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.exception.AssociateDetailsNotFoundException;
import com.cg.payroll.exception.InvalidEmailException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

public class MainClass {

	public static void main(String[] args) throws InvalidEmailException {

		PayrollServices payrollservices = new PayrollServicesImpl(); 

		System.out.println("Enter value case value : ");
		Scanner s = new Scanner(System.in);
		int ch = s.nextInt();
		do {
			switch(ch) {
			case 0:System.out.println("Enter yearlyInvestmentUnder80c ");				
			int yearlyInvestmentUnder80c = s.nextInt();
			System.out.println("Enter firstname ");
			String firstName = s.next();
			System.out.println("Enter lastname ");
			String lastName=s.next();
			System.out.println("Enter department ");
			String department = s.next();
			System.out.println("Enter designation ");
			String designation = s.next();
			System.out.println("Enter pancard ");
			String pancard = s.next();
			System.out.println("Enter emailId ");
			String emailId = s.next();
			System.out.println("Enter basicSalary ");				
			int basicSalary = s.nextInt();
			System.out.println("Enter epf ");				
			int epf = s.nextInt();
			System.out.println("Enter companyPf ");				
			int companyPf = s.nextInt();
			System.out.println("Enter accountNumber ");				
			int accountNumber = s.nextInt();
			System.out.println("Enter bankName ");
			String bankName = s.next();
			System.out.println("Enter ifscCode ");
			String ifscCode = s.next();

			payrollservices.acceptAssociateDetails(yearlyInvestmentUnder80c, firstName, lastName, department, designation, pancard, emailId, basicSalary, epf, companyPf, accountNumber, bankName, ifscCode);
			//payrollservices.acceptAssociateDetails(yearlyInvestmentUnder80c, firstName, lastName, department, designation, pancard, emailId, basicSalary, epf, companyPf, accountNumber, bankName, ifscCode;)
			}

			try {

				int associateID1 =  payrollservices.acceptAssociateDetails(90000, "Devi", "Ratnala", "IT", "Analyst", "BXGPR6235Q", "dssri.26@gmail.com", 35000, 1800, 1800, 14567, "ICICI", "IVIC006I");
				System.out.println("Associate ID1 : " + associateID1);
				int associateID2 =  payrollservices.acceptAssociateDetails(90000, "Devi", "Ratnala", "IT", "Analyst", "BXGPR6235Q", "dssri.26@gmail.com", 35000, 1800, 1800, 14567, "ICICI", "IVIC006I");
				System.out.println("Associate ID2 : " + associateID2);
				int associateID3 = payrollservices.acceptAssociateDetails(90000, "Devi", "Ratnala", "IT", "Analyst", "BXGPR6235Q", "dssri.26@gmail.com", 35000, 1800, 1800, 14567, "ICICI", "IVIC006I");
				System.out.println("associateID3 : " + associateID3);

				Associate associate = new Associate();
				associate = payrollservices.getAssociateDetails(associateID1);
				System.out.println("First name "+associate.getFirstName());
				System.out.println("Details of Associate : " + associate);


				System.out.println("Details of Associate 103 : " + payrollservices.getAssociateDetails(103));

				int netSal1 = payrollservices.calculateNetSalary(associateID1);
				System.out.println("Net Salary1 : " + netSal1);
				int netSal2 = payrollservices.calculateNetSalary(associateID2);
				System.out.println("Net Salary2 : " + netSal2);
				int netSal3 = payrollservices.calculateNetSalary(associateID3);
				System.out.println("Net Salary3 : " + netSal3);
				// associate = (Associate) payrollservices.getallAssociateDetails();
				// System.out.println("Details of all Associates : " + associate);
				/* List<Associate>	 associates = (	List<Associate>) payrollservices.getallAssociateDetails();
			 System.out.println("Details of all Associates : " + associates);
				 */

				//List<Associate> associates = payrollservices.getallAssociateDetails();
				System.out.println("Details of all Associates : " + payrollservices.getallAssociateDetails());

			} catch (AssociateDetailsNotFoundException | InvalidEmailException e) {

				e.printStackTrace();
			}
		}while(ch!=0);
	}
}
