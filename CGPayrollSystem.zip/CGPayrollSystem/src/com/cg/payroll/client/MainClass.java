package com.cg.payroll.client;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.beans.BankDetails;
public class MainClass{
	public static void main(String[] args) {

		Associate [] associates = new Associate[5];
		
	   associates[0] = new Associate(111, 168360, "Devi", "Ratnala", "Java", "Analyst", "BXGPR6235Q", "dssri.26@gmail.com", new Salary(24000, 200, 800), new BankDetails(454642, "ICICI", "DGGD7765H"));
	   
	   associates[1] = new Associate(111, 168360, "Devi", "Ratnala", "Java", "Analyst", "BXGPR6235Q", "dssri.26@gmail.com", new Salary(20000, 200, 800), new BankDetails(454642, "ICICI", "DGGD7765H"));
	   
	   associates[2] = new Associate(111, 168360, "Devi", "Ratnala", "Java", "Analyst", "BXGPR6235Q", "dssri.26@gmail.com", new Salary(28000, 200, 800), new BankDetails(454642, "ICICI", "DGGD7765H"));
	   
	   associates[3] = new Associate(111, 168360, "Devi", "Ratnala", "Java", "Analyst", "BXGPR6235Q", "dssri.26@gmail.com", new Salary(40000, 200, 800), new BankDetails(454642, "ICICI", "DGGD7765H"));
	   
	   associates[4] = new Associate(111, 168360, "Devi", "Ratnala", "Java", "Analyst", "BXGPR6235Q", "dssri.26@gmail.com", new Salary(45000, 200, 800), new BankDetails(454642, "HDFC", "DGGD7765H"));
	   
		
		for (Associate associate : associates) {
			if (associate.getSalary().getBasicSalary() > 20000 && associate.getBankDetails().getBankName() == "HDFC") {
				
				System.out.println(associate.getFirstName() + " " + associate.getLastName() + " " + associate.getPancard() + " " + associate.getSalary().getBasicSalary() + " " + associate.getBankDetails().getAccountNumber() + " " + associate.getBankDetails().getBankName() + " " + associate.getBankDetails().getIfscCode());
				
			}
		}
	
	}
} 