
public class NumList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		int [][][] numList = new int[][][] {{{10,20,30},{40,50,60}},{{70,80,90},{100,110,120}}};
		
		for (int i = 0; i < numList.length; i++) {
			
			for (int j = 0; j < numList[i].length; j++) {
				
				for (int k = 0; k < numList[i][j].length; k++) {
					System.out.println(numList[i][j][k]);
				}
				
			}
		}
	}

}  