package com.cg.banking.client;
import com.cg.banking.beans.*;

public class MainClass {

	public static void main(String[] args) {
		

        Transaction[] transactionsAcc1 = new Transaction[] {
        		
        		new  Transaction(1234, 10, 50000, "UPI", "Bvrm", "Online", "Completed"),
        		new  Transaction(1235, 11, 60000, "CASH", "Pune", "Offline", "Under processing"),
        		new  Transaction(1236, 12, 70000, "IMPS", "Hyd", "Online", "Completed")
        		
        };
        Transaction[] transactionsAcc2= new Transaction[] {
        		
        		new  Transaction(120, 13, 80000, "UPI", "Mumbai", "Online", "Completed"),
        		new  Transaction(121, 14, 90000, "CASH", "Hyd", "Offline", "Completed"),
         
        };
        Transaction[] transactionsAcc3= new Transaction[] {
        		
        		new  Transaction(121, 14, 90000, "CASH", "Hyd", "Offline", "Completed")
                
        };
        
        Account [] accounts = new Account[] {
        		
        		new Account(122, transactionsAcc1),
        		new Account(123, transactionsAcc2),
        		new Account(124, transactionsAcc3), 		
        };
        
        Customer customer = new Customer(123, 99817, 316818, "Devi", "Ratnala", "dssri.26@gmail.com", "BXGPR6235", "26/01/1996", accounts );
        
        for (Account account2 : accounts) {
			
        	System.out.println(account2.getAccountNo());
		}
		
	}

}
