package com.cg.banking.beans;

public class Account {
	private int accountNo, accountBalance;
	private String accountType;
	
	private Transaction [] transactions ;

	public Account() {
		
	}

	public Account(int accountNo, Transaction[] transactions) {
		super();
		this.accountNo = accountNo;
		this.transactions = transactions;
	}

	public int getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public Transaction[] getTransactions() {
		return transactions;
	}

	public void setTransactions(Transaction[] transactions) {
		this.transactions = transactions;
	}

	
	
	
}
