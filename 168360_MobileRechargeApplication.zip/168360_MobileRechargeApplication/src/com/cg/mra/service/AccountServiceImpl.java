package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.exceptions.AccountDetailsNotFoundException;
import com.cg.mra.exceptions.InvalidRechargeAmoutException;
import com.cg.mra.exceptions.MobileNumberNotEqualsTenDigitException;

public class AccountServiceImpl implements AccountService{
	
	AccountDao accountDao= new AccountDaoImpl();
    public AccountServiceImpl() {   }
	@Override
	public Account getAccountDetails(String mobileNo)
			throws AccountDetailsNotFoundException, MobileNumberNotEqualsTenDigitException {
		if(mobileNo.length()!=10) throw new MobileNumberNotEqualsTenDigitException("ERROR: Given Mobile Number Is Not Equals Ten Digit.");
        Account account= accountDao.getAccountDetails(mobileNo);
        if(account== null) throw new AccountDetailsNotFoundException("ERROR:  Given Account Id Does Not Exist");
        else
            return account;
		
	}

	@Override
	public int rechargeAccount(String mobileNo, double rechargeAmount) throws AccountDetailsNotFoundException, MobileNumberNotEqualsTenDigitException, InvalidRechargeAmoutException {
		if(mobileNo.length()!=10) throw new MobileNumberNotEqualsTenDigitException("ERROR: Given Mobile Number Is Not Equals Ten Digit.");
        if(rechargeAmount<=0) throw new InvalidRechargeAmoutException("ERROR:  Given Recharge Amount Is Not Valid.");
        Account account= this.getAccountDetails(mobileNo);
        if(account== null) throw new AccountDetailsNotFoundException("ERROR:  Given Account Id Does Not Exist");
        account.setAccountBalance(this.getAccountDetails(mobileNo).getAccountBalance()+rechargeAmount);
        return (int) account.getAccountBalance();
	}

    
}