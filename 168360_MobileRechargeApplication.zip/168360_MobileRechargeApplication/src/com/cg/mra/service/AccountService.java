package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.exceptions.AccountDetailsNotFoundException;
import com.cg.mra.exceptions.InvalidRechargeAmoutException;
import com.cg.mra.exceptions.MobileNumberNotEqualsTenDigitException;

public interface AccountService {
	Account getAccountDetails(String mobileNo) throws AccountDetailsNotFoundException, MobileNumberNotEqualsTenDigitException;
    int rechargeAccount(String mobileNo, double rechargeAmount) throws AccountDetailsNotFoundException, MobileNumberNotEqualsTenDigitException, InvalidRechargeAmoutException;
}
