package com.cg.mra.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.mra.beans.Account;
import com.cg.mra.util.MraUtil;

public class AccountDaoImpl implements AccountDao{
    
    
    public AccountDaoImpl() {   

        MraUtil.accountEntry= new HashMap<>();
        MraUtil.accountEntry.put("9010210131", new Account("Prepaid", "Vaishali", 200));
        MraUtil.accountEntry.put("9823920123", new Account("Prepaid", "Megha", 453));
        MraUtil.accountEntry.put("9932012345", new Account("Prepaid", "Vikas", 631));
        MraUtil.accountEntry.put("9010210131", new Account("Prepaid", "Anju", 521));
        MraUtil.accountEntry.put("9010210131", new Account("Prepaid", "Tushar", 632));
    }

    @Override
    public Account getAccountDetails(String mobileNo) {
        return MraUtil.accountEntry.get(mobileNo);
    }

    @Override
    public int rechargeAccount(String mobileNo, double rechargeAmount) {
        MraUtil.accountEntry.put(mobileNo, this.getAccountDetails(mobileNo));
        return (int) this.getAccountDetails(mobileNo).getAccountBalance();
    }

}