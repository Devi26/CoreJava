package com.cg.mra.test;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.mra.beans.Account;
import com.cg.mra.exceptions.AccountDetailsNotFoundException;
import com.cg.mra.exceptions.MobileNumberNotEqualsTenDigitException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;
import com.cg.mra.util.MraUtil;

public class MraServicesTest {
    private static AccountService accountService;

    @BeforeClass
    public static void setUpTestEnv() {
        accountService= new AccountServiceImpl();
    }

    @Before
    public void setUpTestData() {
        MraUtil.accountEntry.put("9010210131", new Account("Prepaid", "Vaishali", 200));
        MraUtil.accountEntry.put("9823920123", new Account("Prepaid", "Megha", 453));
        MraUtil.accountEntry.put("9932012345", new Account("Prepaid", "Vikas", 631));
    }

    @Test(expected= AccountDetailsNotFoundException.class)
    public void testGetAccountDetailsForInvalidData() throws AccountDetailsNotFoundException, MobileNumberNotEqualsTenDigitException{
        accountService.getAccountDetails("9728593567");
    }


    @After
    public void tearDownTestData() {
        MraUtil.accountEntry.clear();
    }

    @AfterClass
    public static void tearDownTestEnv() {
        accountService= null;
    }

}