package com.cg.module1_assignment;

import java.io.File;
import java.util.Scanner;

public class FileMain {

    public static void main(String[] args) {
        Scanner input = null;
        try {
            input = new Scanner(new File("D:\\abc.txt"));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        int counter=0,evenCounter=0;
        while(input.hasNextDouble()) {
            int next = input.nextInt();
            ++counter;
            if(next%2==0) {
                System.out.println(next);
                evenCounter++;
            }
        }
        System.out.println("\nEven Numbers: "+evenCounter);
    }
}