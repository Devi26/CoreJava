package com.cg.module1_assignment;

import java.util.Scanner;

public class PersonMain {
    public static void main(String args[]) {
        
        Person p = new Person(18, 39, "Madhesh", "Sr", Gender.Male ,"45641215");
        System.out.println("Person Details:"+"\n"+"____________"+"\n"+p.getFirstName()+"\n"+p.getLastName()+"\n"+
                    p.getGender()+"\n"+p.getAge()+"\n"+p.getWeight());
        Scanner s = new Scanner(System.in);
        int num = s.nextInt();
        if(num<0) System.out.println("Negative");
        else System.out.println("positive");
    }
}
