package com.cg.module1_assignment;

public enum Gender {

    Female,Male;
    
}