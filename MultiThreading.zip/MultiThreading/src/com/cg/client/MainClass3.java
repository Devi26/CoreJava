package com.cg.client;

import com.cg.threaddemo.RunnableResource;

public class MainClass3 {

	public static void main(String[] args) {
		/*Runnable runnableResources = ()->{
			for(int i = 1 ; i<=10; i++)
				System.out.println("Tick    " + i );
		};
		Thread th1 = new Thread(runnableResources);
		th1.start();*/
		
	//Thread th2 = new Thread(()->)
			
		
	}

}
