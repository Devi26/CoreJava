package com.cg.client;

import com.cg.threaddemo.RunnableResource;

public class MainClass {

	public static void main(String[] args) {
		
		RunnableResource  runnableResource = new RunnableResource();
		
		Thread th1  = new Thread(runnableResource, "th1");
		 th1.start();
		 Thread th2 = new Thread(runnableResource, "th2");
		 th2.start();
	}

}
