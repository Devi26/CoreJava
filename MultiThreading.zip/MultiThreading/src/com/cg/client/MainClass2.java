package com.cg.client;

import com.cg.threaddemo.EvenOddNumbers;

public class MainClass2 {

	public static void main(String[] args) {
		
		EvenOddNumbers evenOddNumbers = new EvenOddNumbers();
		Thread t = new Thread(evenOddNumbers);
		t.start();
	}

}
