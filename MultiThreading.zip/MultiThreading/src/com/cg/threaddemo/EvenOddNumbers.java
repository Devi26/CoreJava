package com.cg.threaddemo;

public class EvenOddNumbers implements Runnable {

	@Override
	public void run() {
		for(int i=0;i<100;i++) {
			if(i%2==0)
				System.out.println("even numbers"+i);
			if(i%2!=0)
				System.out.println("odd numbers"+i);
				
		}
	}
}





