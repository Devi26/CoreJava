package com.cg.threaddemo;

public class RunnableResource implements Runnable {

	@Override
	public void run() {
		
		Thread t = Thread.currentThread();
		try {
			if(t.getName().equals("th1")) {
				for (int i = 0; i <= 10; i++) {
					Thread.sleep(1000);
					System.out.println("Tick    " + i + " " + t.getName());
				}	
			}
			else if (t.getName().equals("th2")) {
				for (int i = 0; i <= 10; i++) {
					Thread.sleep(1000);
					System.out.println("Tok    " + i + " " + t.getName());
			}
		}
			
		} catch (InterruptedException e) {
			  
		}
	}

}
