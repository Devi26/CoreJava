package com.cg.project.client;

import com.cg.project.beans.Address;
import com.cg.project.beans.Associate;

public class MainClass {
	public static void main(String[] args) {
		
		Associate associate1 = new Associate("Devi", "Ratnala", 168360, 10000, 20000);
		Associate associate2 = new Associate("Devi", "Ratnala", 168360, 10000, 20000);
		
		if(associate1==associate2)
			System.out.println("Both the objects associate1, associate2 have same references");
		else
			System.out.println("Both the objects associate1, associate2 have different references");
		
		System.out.println();
	
		if(associate1.equals(associate2))
			System.out.println("Both the objects associate1, associate2 have same data");
		else
			System.out.println("Both the objects associate1, associate2 have different data");
		System.out.println();
		
		String s1 = associate1.toString();
		String s2 = associate2.toString();
		System.out.println(s1);
		System.out.println(s2);
		
		Associate associate3 = new Associate("Devi", "Ratnala", 168360, 10000, 20000, new Address(534208, "Komarada", "Andhra Pradesh"));
		Associate associate4 = new Associate("Devi", "Ratnala", 168360, 10000, 20000, new Address(534204, "Komarada", "Andhra Pradesh"));
	
		if(associate3==associate4)
			System.out.println("Both the objects associate3, associate4 have same references");
		else
			System.out.println("Both the objects associate3, associate4 have different references");
		
		
		if(associate3.equals(associate4))
			System.out.println("Both the objects associate3, associate4 have same data");
		else
			System.out.println("Both the objects associate3, associate4 have different data");
		String s3 = associate3.toString();
		String s4 = associate4.toString();
		System.out.println(s3);
		System.out.println(s4);
		
			
	}

}
