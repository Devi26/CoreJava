package com.cg.calculator.client;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.calculator.services.MathServices;
import com.cg.calculator.services.MathServicesImpl;

public class MainClass {

	public static void main(String[] args) {
		try {
			Scanner ref = new Scanner(System.in);
			
			System.out.println("Enter the first Number : ");
			int num1 = ref.nextInt();
			
			System.out.println("Enter the second Number : ");
			int num2 = ref.nextInt();
			
			MathServices mathServices = new MathServicesImpl();
			
			int  addResult = mathServices.add(num1, num2); 
			System.out.println("Ans :- " + addResult);
			
			int  subResult = mathServices.sub(num1, num2); 
			System.out.println("Ans :- " + subResult);
			
			int  mulResult = mathServices.mul(num1, num2); 
			System.out.println("Ans :- " + mulResult);
			
			int  divResult = mathServices.div(num1, num2); 
			System.out.println("Ans :- " + divResult);
		}
		catch(InputMismatchException e) {
			System.err.println("Enter only Numbers");
		}
		catch(ArithmeticException e) {
			System.err.println(e.getMessage() + " " + " Enter other than zero ");
		}
		catch (Exception e) {
			System.err.println("well can't say anything");
		}

		System.out.println("Code after catch block");
	}

}
