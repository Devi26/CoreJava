package com.cg.calculator.test;
import static org.junit.Assert.*;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.calculator.exception.InvalidNumberRangeException;
import com.cg.calculator.services.MathServices;
import com.cg.calculator.services.MathServicesImpl;
public class MathServicesTest {
	
	private static MathServices mathServices;
	private int firstInvalidNumber, secondInvalidNumber, firstValidNumber, secondValidNumber;
	
	@BeforeClass
	public static void setUpTestEnv() {
		mathServices = new MathServicesImpl();
	}
	
	@Before
	public void setIpTestData() {
		firstInvalidNumber = -100;
		firstValidNumber = 100;
		secondInvalidNumber = -200;
		secondValidNumber = 200;
	}
	
	@Test(expected = InvalidNumberRangeException.class)
	public void testAddFirstInvalidNumber() throws InvalidNumberRangeException{
		mathServices.add(firstInvalidNumber, secondValidNumber);
	}
	@Test(expected = InvalidNumberRangeException.class)
		public void testAddSecondInvalidNumber() throws InvalidNumberRangeException{
			mathServices.add(firstValidNumber, secondInvalidNumber);
	}	
	
	@Test
		public void testAddBothValidNumber() throws InvalidNumberRangeException{
		int expectedAns = 300;
		int acctualAns = mathServices.add(firstValidNumber, secondValidNumber);
		org.junit.Assert.assertEquals(expectedAns, acctualAns);
		}	
	
	@AfterClass
	public static void tearDownTestEnv() {
		 mathServices = null;
	}
	
	/*@Test
	public void test() {
		fail("Not yet implemented");
	}*/

}
