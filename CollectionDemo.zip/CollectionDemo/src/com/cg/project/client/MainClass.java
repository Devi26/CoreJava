package com.cg.project.client;
import java.util.ArrayList;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.Stream;

import com.cg.project.beans.Associate;
public class MainClass {

	public static void main(String[] args) {


		ArrayList<Associate> associateList=new ArrayList<>();

		associateList.add(new Associate(111, 11, "Devi", "Ratnala"));
		associateList.add(new Associate(112, 12, "Surya", "Ratnala"));
		associateList.add(new Associate(113, 13, "Sri", "Ratnala"));
		associateList.add(new Associate(114, 2, "Sri", "Ratnala"));
		associateList.add(new Associate(113, 2, "Sri", "Ratnala"));
		associateList.add(new Associate(113, 2, "Sri", "Ratnala"));
		associateList.add(new Associate(113, 2, "Sri", "Ratnala"));

		Stream<Associate> stream1 = associateList.stream();
		Stream<Associate> stream2 = stream1.distinct();
		Stream<Associate> stream3 = stream2.filter((associate)->associate.getFirstName().startsWith("S"));
	
		stream3.forEach(associate->System.out.println(associate));
		//System.out.println(stream3.count());
//		associateList.stream()
//		.distinct()
//		.filter(associate->associate.getFirstName().startsWith("I"))
//		.forEach(associate->System.out.println(associate));
//
//		System.out.println(associateList.stream().map(associate->associate.getSalary()));
//		
//		printEmployeeDetails1(associateList, e->e.getFirstName().startsWith("D"));
//		printEmployeeDetails2(associateList, e->e.getFirstName().startsWith("D"), e->System.out.println(e));
//
//		associateList.forEach(e->System.out.println(e));
	}
	@FunctionalInterface
	public interface Condition<T> {
		boolean startWith(T associates);
	}
	private static void printEmployeeDetails1(ArrayList<Associate>associateList , Condition<Associate> condition) {
		for (Associate associate2 : associateList)
			if(condition.startWith(associate2))
				System.out.println(associate2);     
	}
	private static void printEmployeeDetails2(ArrayList<Associate>associateList ,Predicate<Associate>predicate, Consumer<Associate>consumer) {
		for (Associate associate2 : associateList)
			if(predicate.test(associate2))
				consumer.accept(associate2);
	}
	
	
}
