package com.cg.project.collectionsdemo;

import java.util.ArrayList;
import java.util.Collections;

import com.cg.project.beans.Associate;

public class ListClassesDemo {
	public static void arrayListClassDemo() {
		
	ArrayList<Associate> associates = new ArrayList<>();
	
	//insert
	associates.add(new Associate(1, 15000, "Dei", "Ra"));
	associates.add(new Associate(3, 15000, "Dev", "Rat"));
	associates.add(new Associate(2, 18000, "Surya", "Rt"));
	associates.add(new Associate(4, 5000, "Devi", "Ratnala"));
	
	
	//search
	Associate associateToBeSearch = new Associate(2, 18000, "Surya", "Rat");
	
	int idx = associates.indexOf(associateToBeSearch);
	
	//Associate associate = associates.get(idx);
	
	System.out.println(idx);
	
	//remove
	
	associates.remove(associateToBeSearch);
	
	  //sort
	  Collections.sort(associates);
	

     System.out.println(associates);
	
	Collections.sort(associates, new AssociateComparator());
	
	System.out.println(associates);
	
	//iteration
  	for (Associate associate : associates) {
		System.out.println(associate);
	}
	}
}