package com.cg.project.collectionsdemo;

import com.cg.project.beans.Associate;

public interface StartWithMethod {
	public boolean startWith( Associate associate);

}
