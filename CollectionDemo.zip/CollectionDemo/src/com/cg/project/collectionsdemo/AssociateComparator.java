package com.cg.project.collectionsdemo;

import java.util.Comparator;

import com.cg.project.beans.Associate;

public class AssociateComparator implements Comparator<Associate> {

	@Override
	public int compare(Associate a1, Associate a2) {
	
		return a1.getAssociateID()-a2.getAssociateID();
	}

}
